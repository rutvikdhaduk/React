import styled from 'styled-components'

const Rd = styled.div`
    h1{
        background-color:yellow;
        padding-top:0px;
        margin-top:0px;
    }
`;
export default Rd;