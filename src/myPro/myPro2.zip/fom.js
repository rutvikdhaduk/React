import styled from 'styled-components'

const Fm = styled.div`
    height:95vh;
    background-color:black;
    form{
            background-color:green;
            text-align:center;
            p{
                color:white;
                font-size:20px;
            }
            label{
                color:white;
            }
            .inp{
                background-color:green;
                color:white;
            }
            .btn{
                background-color:green;
                color:white;
            }
        }
`;
export { Fm };